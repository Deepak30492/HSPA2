package com.uhi.hsp.model;

import lombok.Data;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(schema = "hsp")
@Data
@ToString
public class Billing {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "bill_id")
    private Integer billingId;
    @Column(name = "state")
    private String state;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fulfillment_id")
    private Fulfillments fulfillments;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "address_id")
    private Address address;

    @Column(name = "name")
    private String name;
    @Column(name = "email")
    private String email;
    @Column(name = "phone")
    private String phone;

}
