package com.uhi.hsp.repo;

import com.uhi.hsp.model.Provider;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

public interface ProviderRepo extends JpaRepository<Provider, Integer> {
    @Query(nativeQuery = true, value = "SELECT DISTINCT  hp.provider_id, hp.name, hc.category_id, hc.name as cat_name, \n" +
            " hf.fulfillment_id, hf.type, hpr.practitioner_id, hpr.name as practitioner_name, \n" +
            " hpr.gender, hpr.image, hpr.cred, hpr.start_time, hpr.end_time, hpr.consultation_charge,\n" +
            " hpr.currency\n" +
            " from hsp.provider hp\n" +
            " LEFT JOIN \n" +
            " hsp.categories hc\n" +
            " ON \n" +
            " hp.provider_id = hc.provider_id\n" +
            " LEFT JOIN\n" +
            " hsp.fulfillments hf\n" +
            " ON\n" +
            " hc.provider_id = hf.provider_id\n" +
            " LEFT JOIN\n" +
            " hsp.practitioner hpr\n" +
            " ON\n" +
            " hf.practitioner_id = hpr.practitioner_id\n" +
            " WHERE hp.name = ?1")
    public List<Map<Object,Object>> findByProviderName(String providerName);
}
