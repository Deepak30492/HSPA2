package com.uhi.hsp.model;

import lombok.Data;
import lombok.ToString;

import javax.persistence.*;

@Data
@Table(schema = "hsp")
@Entity
@ToString
public class Fulfillments {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "fulfillment_id")
    private Integer fulfillmentId;

    @ManyToOne
    @JoinColumn(name = "provider_id", nullable = false)
    private Provider provider;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Categories categories;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "practitioner_id")
    private Practitioner practitionerId;

    @Column(name = "start_time")
    private String startTime;
    @Column(name = "end_time")
    private String endTime;


    private String type;

}
