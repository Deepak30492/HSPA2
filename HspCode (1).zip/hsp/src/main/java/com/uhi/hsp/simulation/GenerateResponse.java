package com.uhi.hsp.simulation;



public class GenerateResponse {

//	public static AckResponse generateAck() {
//		Ack ack = new Ack().status(Ack.StatusEnum.ACK);
//		return new AckResponse().message(ack).error(new Error());
//	}
//
//	public static OnSearchBody generateOnSearchResponse(SearchBody request) {
//		Catalog catalog = new Catalog().providers(null);
//		OnSearchMessage message = new OnSearchMessage().catalog(null);
//		OnSearchBody response = new OnSearchBody().context(request.getContext()) //
//		.message(null);
//		return null;
//	}

}
