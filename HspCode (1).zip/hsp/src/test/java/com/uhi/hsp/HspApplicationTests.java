package com.uhi.hsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HspApplicationTests {

	@Test
	void contextLoads() {
	}

}
