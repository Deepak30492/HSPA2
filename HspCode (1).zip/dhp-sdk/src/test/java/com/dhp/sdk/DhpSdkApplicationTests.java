package com.dhp.sdk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhpSdkApplicationTests {

	@Test
	void contextLoads() {
	}

}
