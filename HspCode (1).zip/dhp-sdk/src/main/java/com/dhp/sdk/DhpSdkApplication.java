package com.dhp.sdk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DhpSdkApplication {

	public static void main(String[] args) {
		SpringApplication.run(DhpSdkApplication.class, args);
	}

}
