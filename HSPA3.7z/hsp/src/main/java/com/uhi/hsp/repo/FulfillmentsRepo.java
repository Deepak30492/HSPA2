package com.uhi.hsp.repo;

import com.uhi.hsp.model.Fulfillments;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FulfillmentsRepo extends JpaRepository<Fulfillments, Integer> {
}
