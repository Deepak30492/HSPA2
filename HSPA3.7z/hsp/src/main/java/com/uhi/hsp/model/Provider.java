package com.uhi.hsp.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Data
@ToString
@Table(schema = "hsp", name = "provider")
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
public class Provider {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "provider_id")
	private Integer providerId;

	@Column(name = "name")
	private String name;

	@OneToMany(mappedBy = "provider")
	private List<Categories> categories;

	@OneToMany(mappedBy = "provider")
	private List<Fulfillments> fulfillments;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "country")
	private String country;

}
